import json
import boto3
import time

client = boto3.client('rds')
sm_client = boto3.client('secretsmanager')

sns_topic_arn='arn:aws:sns:us-east-1:057679907813:test'

def lambda_handler(event, context):
    response = client.describe_db_instances()
    db_identifiers = []
    for db_instance in response['DBInstances']:
        db_identifiers.append(db_instance['DBInstanceIdentifier'])
    # print(db_identifiers)
    
    response = sm_client.list_secrets()
    # print(response)
    rds_with_secrets_enabled = []
    rotations_enabled_today = []
    for secret in response['SecretList']:
        response = sm_client.get_secret_value(
            SecretId=secret['Name']
        )
        if 'dbInstanceIdentifier' in json.loads(response['SecretString']):
            rds_with_secrets_enabled.append(json.loads(response['SecretString'])['dbInstanceIdentifier'])
            if secret['RotationEnabled'] == True:
                print("rotation already enabled for "+ json.loads(response['SecretString'])['dbInstanceIdentifier'])
            else: 
                try:
                    res = sm_client.rotate_secret(
                        SecretId=secret['Name'],
                        RotationRules={
                            'AutomaticallyAfterDays': 30,
                        }
                    )
                    # time.sleep(5)
                    # print(json.loads(response['SecretString'])['dbInstanceIdentifier'])
                    rotations_enabled_today.append(json.loads(response['SecretString'])['dbInstanceIdentifier'])
                except Exception as e: 
                    print(e)

    
    print(rotations_enabled_today)
    print(rds_with_secrets_enabled)
    print(db_identifiers)
    diff = [x for x in rds_with_secrets_enabled + db_identifiers if x not in rds_with_secrets_enabled or x not in db_identifiers]
    print(diff)
    message = ""
    if(len(rotations_enabled_today)) != 0:
        message = message+"Rotations has been enabled for following databases: "+ json.dumps(rotations_enabled_today)+ "\n"
    if(len(diff)) !=0:
        message= message+"Cannot perform rotation. because, these databases credentials are not managed by secretsmanager: "+ json.dumps(diff)
    print(message)
    if message != "":
        sns_client = boto3.client('sns')
        response = sns_client.publish(
            TargetArn=sns_topic_arn,
            Message=message,
            Subject='Cloudformation Drift Information'
        )
    