import json
import boto3
import time

sns_topic_arn='arn:aws:sns:us-east-1:057679907813:test'

def lambda_handler(event, context):

    cloudformationClient = boto3.client("cloudformation")
    stacks = cloudformationClient.describe_stacks()['Stacks']
    
    drift_details = {}
    for stack in stacks:
        if str(stack['DriftInformation']['StackDriftStatus']) == "DRIFTED":
            try:
                response = cloudformationClient.describe_stack_resource_drifts(
                    StackName=stack['StackName']
                )
                each_drift_detail=[]
                for drift in response['StackResourceDrifts']:
                    if drift['StackResourceDriftStatus'] != 'IN_SYNC':
                        trail_client = boto3.client('cloudtrail')
                        response = trail_client.lookup_events(
                            LookupAttributes=[
                                {
                                    'AttributeKey': 'ResourceName',
                                    'AttributeValue': drift['PhysicalResourceId']
                                },
                            ]
                        )
                        print(response['Events'])
                        if(len(response['Events']) == 0):
                            each_drift_detail.append({"DRIFT_STATUS":drift['StackResourceDriftStatus'],"SERVICE_NAME":drift['ResourceType'],"RESOURCE_NAME":drift['PhysicalResourceId']})
                        else:
                            each_drift_detail.append({"DRIFT_STATUS":drift['StackResourceDriftStatus'],"SERVICE_NAME":drift['ResourceType'],"RESOURCE_NAME":drift['PhysicalResourceId'], "LAST_CHANGED_BY":response['Events'][0]['Username'], "CHANGE_ACTIVITY":response['Events'][0]['EventName']})
                drift_details[stack['StackName']] = each_drift_detail
            except Exception as e:
                print(e)
        
        if str(stack['DriftInformation']['StackDriftStatus']) == "NOT_CHECKED":
            try:
                detection_id = cloudformationClient.detect_stack_drift(StackName=stack['StackName'])['StackDriftDetectionId']
                response = cloudformationClient.describe_stack_drift_detection_status(
                    StackDriftDetectionId=detection_id
                )
                print(response)
                while response['DetectionStatus'] == 'DETECTION_IN_PROGRESS':
                    time.sleep(3)
                    response = cloudformationClient.describe_stack_drift_detection_status(
                        StackDriftDetectionId=detection_id
                    )
                if response['StackDriftStatus'] == 'DRIFTED':
                    response = cloudformationClient.describe_stack_resource_drifts(
                        StackName=stack['StackName']
                    )
                    each_drift_detail=[]
                    for drift in response['StackResourceDrifts']:
                        if drift['StackResourceDriftStatus'] != 'IN_SYNC':
                            trail_client = boto3.client('cloudtrail')
                            response = trail_client.lookup_events(
                                LookupAttributes=[
                                    {
                                        'AttributeKey': 'ResourceName',
                                        'AttributeValue': drift['PhysicalResourceId']
                                    },
                                ]
                            )
                            if(len(response['Events']) == 0):
                                each_drift_detail.append(drift['ResourceType']+ ' with Id '+ drift['PhysicalResourceId']+ ' is '+ drift['StackResourceDriftStatus']+'.')
                            else:
                                each_drift_detail.append(drift['ResourceType']+ ' with Id '+ drift['PhysicalResourceId']+ ' is '+ drift['StackResourceDriftStatus']+'. Last changes made by user '+response['Events'][0]['Username'] +' is '+response['Events'][0]['EventName'])
                    drift_details[stack['StackName']] = each_drift_detail
            except Exception as e:
                print(e)
         
    print(drift_details)
    
    if len(drift_details) != 0:
        try:
            sns_client = boto3.client('sns')
            response = sns_client.publish(
                TargetArn=sns_topic_arn,
                Message=json.dumps(drift_details, indent=4, sort_keys=True),
                Subject='Cloudformation Drift Information'
            )
        except Exception as e:
            print(e)
    return "tetsst"

